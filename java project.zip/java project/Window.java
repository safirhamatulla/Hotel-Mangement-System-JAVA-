import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Window extends JFrame{
	public static void main(String[]args){

		JFrame a=new JFrame("Login Window");
		JLabel l=new JLabel("User Name");
		JLabel l2=new JLabel("Password");
		JTextField tf=new JTextField(28);
		JTextField tf2=new JTextField(28);
		JButton b=new JButton("Login");
		b.setBounds(200,120,90,45);
		l.setBounds(20,15,120,30);
		l2.setBounds(145,15,200,30);
		tf.setBounds(20,53,120,30);
		tf2.setBounds(145,55,200,30);
		a.add(l);a.add(tf);
		a.add(l2);a.add(tf2);
		a.add(b);
		a.setLayout(null);
		a.setSize(280,400);
		a.setVisible(true);
		
		b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                try{
                    String file= "login .txt";
                    String username = tf.getText();
                    String password = tf2.getText();
                    FileReader fr = new FileReader(file);
                    BufferedReader br = new BufferedReader(fr);

                    String line,user,pass;



                    boolean isLoginSuccess = false;
                    while((line=br.readLine())!=null){
                        user=line.split(" ")[1].toLowerCase();
                        pass=line.split(" ")[2].toLowerCase();
                        System.out.println(user);
                        System.out.println(pass);
                        if(user.equals(username)&&pass.equals(password)){

                            isLoginSuccess=true;
                            a.setVisible(false);
                            
                            Window1 m = new Window1();
                            break;
				    }
                    if(!isLoginSuccess){
                      JOptionPane.showMessageDialog(null, "USERNAME/PASSWORD WRONG", "WARNING!!", JOptionPane.WARNING_MESSAGE);
                    }
                    fr.close();
                }
                
            }
            catch (Exception z){
                    z.printStackTrace();
                }
            }
        });

	}
}
