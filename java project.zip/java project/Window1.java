import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

class Window1 extends JFrame{
	 Window1(){
		JFrame a=new JFrame ("Resarvation");
		JLabel l=new JLabel("Room type");
		JLabel l2=new JLabel("Room Rent");
		JLabel l3=new JLabel("Room Vacancy");
		JLabel l4=new JLabel("Arrival Date");
		JLabel l5=new JLabel("Departure Date");
		JTextField tf=new JTextField();
		JTextField tf2=new JTextField();
		JTextField tf3=new JTextField();
		JTextField tf4=new JTextField();
		JTextField tf5=new JTextField();
		JButton b=new JButton("Reserve");
		b.setBounds(50,400,95,30);
		l.setBounds(150,100,300,30);
		l2.setBounds(150,180,300,30);
		l3.setBounds(150,260,300,30);
		l4.setBounds(150,340,300,30);
		l5.setBounds(150,420,300,30);
		tf.setBounds(150,150,300,30);
		tf2.setBounds(150,230,300,30);
		tf3.setBounds(150,310,300,30);
		tf4.setBounds(150,390,300,30);
		tf5.setBounds(150,470,300,30);
		a.add(l);a.add(tf);
		a.add(l2);a.add(tf2);
		a.add(l3);a.add(tf3);
		a.add(l4);a.add(tf4);
		a.add(l5);a.add(tf5);
		a.add(b);
		a.setLayout(null);
		a.setSize(1400,1400);
		a.setVisible(true);
	}
}